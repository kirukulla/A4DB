package com.hasids;

public class HASIDSConstants {

	public HASIDSConstants() {
		// TODO Auto-generated constructor stub
	}

	public static final int DIM_MAX_RECORDS = 2000000000;
	public static final int FACT_FLOAT_MAX_BYTES = 2000000000;
	public static final int FACT_DOUBLE_MAX_BYTES = 1900000000;
	
	public static final String FACT_FLOAT_ZERO_STRING = "0000000000";
	public static final String FACT_DOUBLE_ZERO_STRING = "0000000000000000000";
	
	public static final short THREAD_INACTIVE = 0;
	public static final short THREAD_ACTIVE = 1;
	public static final short THREAD_COMPLETE = 2;
	public static final short THREAD_FAILED = 3;
	
	public static final int MAX_PARALLELFILEREAD_THREADS = 20000;
}
