package com.hasids.io;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.util.concurrent.TimeUnit;
import java.nio.*;

/**
 * 
 * @author Durga Turaga
 * @since 08/20/2017
 *
 * This class is a test writer component. It allows the creation of data segments 
 * and writing data to the data segments. File sizes are restricted to 2 billion bytes.
 * 
 * For the write to work correctly, the position array must be sorted in ascending order
 * to ensure all writes are complete in a single parse from the lowest position to the
 * highest position
 * 
 * Another approach to conserve memory is to have a write function with the input containing 
 * a byte array of length the is the difference of highest position minus lowest position + 1
 * and then setting the position in the array to the byte value that needs to be written 
 * to the file. The second input would be an integer indicating the position of the file 
 * where the write of the array should begin with. All values in the byte array that designate
 * a write value should have a byte value > 0. 
 */
public class TestDimDataWriter implements Runnable {
	
	private String _datasetName;
	private int _recordCount;
	private RandomAccessFile _randomAccessFile;
	int[] _position; //position
	byte[] _values; // values
	public static final short INACTIVE = 0;
	public static final short ACTIVE = 1;
	public static final short COMPLETE = 2;
	public static final short FAILED = 3;
	private int _status = TestDimDataWriter.INACTIVE;
	
	public TestDimDataWriter(String datasetName) throws Exception {
		// TODO Auto-generated constructor stub
		this._datasetName = datasetName;
		try {
			File f = new File(this._datasetName);
			if (!f.exists())
				throw new Exception("File " + this._datasetName + " does not exist! Open constructor with record length to create a new file");
			this._recordCount = (int)f.length();
		}
		catch(Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	public TestDimDataWriter(String datasetName, int recordCount) throws Exception {
		
		if (datasetName == null || datasetName.length() <= 0)
			throw new Exception ("Invalid dataset name");
		
		this._datasetName = datasetName;
		if (recordCount <= 0 || recordCount > 2000000000) // 2 billion bytes
			throw new Exception ("Record count must be > 0 and <= 2 billion");
		
		this._recordCount = recordCount;
		
		try {
			this.createSegment();
		}
		catch (Exception e) {
			//throw new Exception(e.getMessage());
		}
	}
	
	public String getDatasetName() {
		return this._datasetName;
	}
	
	public int getRecordCount() {
		return this._recordCount;
	}
	
	public void setWriteDataPositionBuffer(int[] position) throws Exception {
		
		for (int i = 0; i < position.length; i++)
		{
			if (position[i] < 0 || position[i] > this._recordCount - 1)
				throw new Exception ("Positions to be set should be >=0 and <= file length/record count");
		}
		
		this._position = position;
	}
	
	public void setWriteDataValues(byte[] values) throws Exception {
		
		for (int i = 0; i < values.length; i++)
		{
			if (values[i] < 0 || values[i] > 255)
				throw new Exception ("Values to be set should be >= 0 and <= 255; 0 is reserved to mean no change");
		}
		
		this._values = values;
	}
	
	private void createSegment() throws Exception {
		this._status = TestDimDataWriter.ACTIVE;
		byte buf = 0;
		FileChannel rwChannel = null;
		
		long beginTime = System.nanoTime();
		
		try {
			File f = new File(this._datasetName);
			if (f.exists())
				throw new Exception("File " + this._datasetName + " exists! Cannot create segment");
			
			_randomAccessFile = new RandomAccessFile(this._datasetName, "rw");
			rwChannel = _randomAccessFile.getChannel();
			ByteBuffer buffer = rwChannel.map(FileChannel.MapMode.READ_WRITE, 0, this._recordCount);
			for (int i = 0; i < this._recordCount; i++)
			{
				buffer.put(buf);
			}
			rwChannel.close();
			_randomAccessFile.close();
			
			System.out.println("File " + this._datasetName + " length = " + f.length());
			
		}
		catch(Exception e) {
			this._status = TestDimDataWriter.FAILED;
			throw new Exception(e.getMessage());
		}
		finally {
			if (this._status == TestDimDataWriter.ACTIVE)
				this._status = TestDimDataWriter.COMPLETE;
			long endTime = System.nanoTime();
			long elapsedTimeInMillis = TimeUnit.MILLISECONDS.convert((endTime - beginTime), TimeUnit.NANOSECONDS);
            System.out.println("Segment creation time for : " + this._recordCount + " = " + elapsedTimeInMillis + "  Milliseconds");
            
			try {
				if (rwChannel != null)
					rwChannel.close();
				if (_randomAccessFile != null)
					_randomAccessFile.close();
			}
			catch (Exception e) {
				throw new Exception(e.getMessage());
			}
		}
	}
	
	public void writeToSegment(int noIterations ) throws Exception {
		
		this._status = TestDimDataWriter.ACTIVE;
		
		FileChannel rwChannel = null;
		long beginTime = System.nanoTime();
		
		try {
			if (_position == null || _values == null || _position.length <= 0 || (_position.length != _values.length))
				throw new Exception("Null Data or data length does not match values length! No data to write");
			
			
			
			File f = new File(this._datasetName);
			if (!f.exists())
				this.createSegment();
			
			_randomAccessFile = new RandomAccessFile(this._datasetName, "rw");
			rwChannel = _randomAccessFile.getChannel();
			
			MappedByteBuffer buffer = rwChannel.map(FileChannel.MapMode.READ_WRITE, 0, this._recordCount);
			
			// iterate 
			for (int count = 0; count < noIterations; count++)
				for (int i = 0; i < _position.length; i++)
					buffer.put(_position[i] + count * 5, _values[i]);
			
			rwChannel.close();
			_randomAccessFile.close();
			
		}
		catch(Exception e) {
			this._status = TestDimDataWriter.FAILED;
			throw new Exception(e.getMessage());
		}
		finally {
			if (this._status == TestDimDataWriter.ACTIVE)
				this._status = TestDimDataWriter.COMPLETE;
			
			try {	
				long endTime = System.nanoTime();
				long elapsedTimeInMillis = TimeUnit.MILLISECONDS.convert((endTime - beginTime), TimeUnit.NANOSECONDS);
	            System.out.println("File based read/write time : " + elapsedTimeInMillis + "  Milliseconds");
	            
				if (rwChannel != null)
					rwChannel.close();
				if (_randomAccessFile != null)
					_randomAccessFile.close();
			}
			catch (Exception e) {
				throw new Exception(e.getMessage());
			}
			
		}
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			this.writeToSegment(100);
		}
		catch (Exception e) {
			;// log this
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		try {
			TestDimDataWriter t = new TestDimDataWriter ("c:\\users\\dpras\\tempdata\\test.txt",2000000000);
			int[] data = {0,1,2,3,4}; //position
			byte[] values = {66,67,68,69,70}; // values
			
			t.setWriteDataPositionBuffer(data);
			t.setWriteDataValues(values);
			t.writeToSegment(100000000);
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}

	}

}
