/**
 * 
 * @author Durga Turaga
 * @since 08/20/2017
 * @copyright A4DATA LLC; All rights reserved
 *
 * This class is a test dimension data reader wherein the data is stored in the HASIDS/BOBS
 * format. Data is read based on input filters and the same is returned as BitSets. The values
 * in the BitSet set to either 0 or 1, 1 representing the identifiers/cluster ids/unary keys matching
 * the input filer. The class implements both the Runnable and Observable interfaces. Runnable
 * interface implementation allows this class to be executed as a thread within a ThreadGroup. The
 * Observable interface implementation allows this class to be monitored by an Observer.   
 */

package com.hasids.io;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.concurrent.TimeUnit;

import java.util.Observable;
import java.util.BitSet;
import java.util.TreeSet;
import java.util.Iterator;


public class TestDimDataReader extends Observable implements Runnable {

	public static final int TYPE_SET = 1;
	public static final int TYPE_MAP = 2;
	public static final int DIM_MAX_RECORDS = 2000000000;
	
	private String _filename;
	private BitSet _computedBitSet = null;
	private long _elapsedTimeInMillis = 0L; 
	private long _filteredCount = 0L;
	private long _filterLowRange = 1L; // for beginning of file, it must be set to 1
	private long _filterHighRange = 0; // high range - exclusive
	
	private char[] _filter;
	private byte[] _memoryBuffer;
	
	/**
	 * Constructor 
	 * 
	 * @param filename  
	 * @throws Exception
	 */
	public TestDimDataReader(String filename) throws Exception {
		this(filename, 1L);
	}
	
	/**
	 * Constructor
	 * 
	 * @param filename
	 * @param lowRange
	 * @throws Exception
	 */
	public TestDimDataReader(String filename, long lowRange) throws Exception {
		this._filename = filename;
		if (lowRange <= 0)
			throw new Exception("Low range must be > 0");
		this._filterLowRange = lowRange;
	}
	
	/**
	 * Constructor
	 * 
	 * @param filename
	 * @param lowRange
	 * @param highRange
	 * @throws Exception
	 */
	public TestDimDataReader(String filename, long lowRange, long highRange ) throws Exception {
		this._filename = filename;
		if (lowRange <= 0 || highRange <= 0)
			throw new Exception("Low range must be > 0 and high range must be > 0");
		if (lowRange > highRange)
			throw new Exception("Low range must be <= high range");
		if (lowRange > DIM_MAX_RECORDS || highRange > DIM_MAX_RECORDS)
			throw new Exception("Low range and high range must be <= " + DIM_MAX_RECORDS);
		
		this._filterLowRange = lowRange;
		this._filterHighRange = highRange;
	}
	
	/**
	 * Set an array of characters as filters for data read operations.
	 * 
	 * @param c Array of characters
	 */
	public void setFilter(char[] c) {
		this._filter = c;
	}
	
	/**
	 * Returns the filter set for the class instance
	 * 
	 * @return filter
	 */
	public char[] getFilter() {
		return this._filter;
	}
	
	/**
	 * Returns the dataset filename associated with the class instance.
	 * 
	 * @return dataset name
	 */
	public String getFilename() {
		return this._filename;
	}
	
	/**
	 * Returns the count of keys read from the file and associated to the input filter
	 * 
	 * @return filter count
	 */
	public long getFilteredCount() {
		return this._filteredCount;
	}
	
	/**
	 * returns the time elapsed for the file read operations.
	 * 
	 * @return elapsed time
	 */
	public long getElapsedTime() {
		return this._elapsedTimeInMillis;
	}
	
	/**
	 * Returns the low range of the key set associated to the filter. This need not be the 
	 * segment low value, but a position within the file where the first occurrence of the
	 * filter is found.
	 * 
	 * @return filter low range
	 */
	public long getFilterLowRange() {
		return this._filterLowRange;
	}
	
	/**
	 * Returns the high range of the key set associated to the filter. This need not be the 
	 * segment high value, but a position within the file where the last occurrence of the
	 * filter is found.
	 * 
	 * @return filter low range
	 */
	public long getFilterHighRange() {
		return this._filterHighRange;
	}
	
	/**
	 * Retruns the BitSet associated to the filtered keys
	 * 
	 * @return Result Bit Set
	 */
	public BitSet getResultBitSet() {
		return this._computedBitSet;
	}
	
	/**
	 * Read each and every character of the specified MappedByteBuffer that is not a null and set
	 * the bit in the BitSet to 1.
	 * 
	 * @param buffer Mapped Byte Buffer created from a File Channel associated with a
	 * Random Access File.
	 */
	private void readDataAll(MappedByteBuffer buffer) {
		//System.out.println("Checking entire range of characters");
		int read;
    	for (int i = 0; i < buffer.limit(); i++) {
    		
    		// read each character byte
    		read = (char)buffer.get();
    		//_memoryBuffer[i] = (byte)read;
    		
    		// ignore the nulls
			if (read > 0)
				_computedBitSet.set(i);
    	}
	}
	
	/**
	 * 
	 * @param buffer
	 * @param k
	 * @param rangeCheck
	 */
	private void readDataRange(MappedByteBuffer buffer, int k, int[][] rangeCheck) {
		//System.out.println("Checking ranges of characters : " + k);
		int read;
    	for (int i = 0; i < buffer.limit(); i++) {
			
        	// read each character byte
			read = (char)buffer.get();
			//_memoryBuffer[i] = (byte)read;
			// 
			for (int j = 0; j <= k; j++) {
				if (read >= rangeCheck[j][0] && read <= rangeCheck[j][1]) {
					_computedBitSet.set(i);
				}
			}
			
		}
	}
	
	private void readDataFilter(MappedByteBuffer buffer) {
		//System.out.println("Checking ranges of characters : " + this._filter.length);
    	int read;
		for (int i = 0; i < buffer.limit(); i++) {
			
        	// read each character byte
			read = (char)buffer.get();
			//_memoryBuffer[i] = (byte)read;
			for (int j = 0; j < this._filter.length; j++)
				if (read == this._filter[j])
					_computedBitSet.set(i);
		}
	}
	
	private void readDataSingleCheck(MappedByteBuffer buffer) {
		//System.out.println("Checking single character");
		int read;
    	for (int i = 0; i < buffer.limit(); i++) {
    		
    		// read each character byte
    		read = (char)buffer.get();
    		//_memoryBuffer[i] = (byte)read;
    		// ignore the nulls
			if (read == _filter[0])
				_computedBitSet.set(i);
    	}
	}
	
	private BitSet getDataByFilter(char[] filter, int lowRange, int highRange) throws Exception{
		//System.out.println("Retreiving bitset for range : " + lowRange + "/" + highRange);
    	int read;
    	BitSet b;
    	
    	if (lowRange < 0 || lowRange > highRange || 
    			lowRange >= _memoryBuffer.length || highRange < 0 || 
    			highRange > _memoryBuffer.length)
    		throw new Exception("Invalid low/high range values");
    	
    	b = new BitSet(highRange - lowRange);
		for (int i = 0; i < _memoryBuffer.length; i++) {
			
        	// read each character byte
			read = (char)_memoryBuffer[i];
			
			for (int j = 0; j < this._filter.length; j++)
				if (read == this._filter[j])
					b.set(i);
		}
		
		return b;
	}
	
	private BitSet getDataGTFilter(char filter, int lowRange, int highRange) throws Exception{
		//System.out.println("Retreiving bitset for range : " + lowRange + "/" + highRange);
    	int read;
    	BitSet b;
    	
    	if (lowRange < 0 || lowRange > highRange || 
    			lowRange >= _memoryBuffer.length || highRange < 0 || 
    			highRange > _memoryBuffer.length)
    		throw new Exception("Invalid low/high range values");
    	
    	b = new BitSet(highRange - lowRange);
		for (int i = 0; i < _memoryBuffer.length; i++) {
			
        	// read each character byte
			read = (char)_memoryBuffer[i];
			
			if (read >= filter)
				b.set(i);
		}
		
		return b;
	}
	
	private BitSet getDataLTFilter(char filter, int lowRange, int highRange) throws Exception{
		//System.out.println("Retreiving bitset for range : " + lowRange + "/" + highRange);
    	int read;
    	BitSet b;
    	
    	if (lowRange < 0 || lowRange > highRange || 
    			lowRange >= _memoryBuffer.length || highRange < 0 || 
    			highRange > _memoryBuffer.length)
    		throw new Exception("Invalid low/high range values");
    	
    	b = new BitSet(highRange - lowRange);
		for (int i = 0; i < _memoryBuffer.length; i++) {
			
        	// read each character byte
			read = (char)_memoryBuffer[i];
			
			if (read <= filter)
				b.set(i);
		}
		
		return b;
	}
	
	private BitSet getDataInBetweenFilter(char lowFilter, char highFilter, int lowRange, int highRange) throws Exception{
		//System.out.println("Retreiving bitset for range : " + lowRange + "/" + highRange);
    	int read;
    	BitSet b;
    	
    	if (lowRange < 0 || lowRange > highRange || 
    			lowRange >= _memoryBuffer.length || highRange < 0 || 
    			highRange > _memoryBuffer.length)
    		throw new Exception("Invalid low/high range values");
    	
    	b = new BitSet(highRange - lowRange);
		for (int i = 0; i < _memoryBuffer.length; i++) {
			
        	// read each character byte
			read = (char)_memoryBuffer[i];
			
			if (read >= lowFilter && read <= highFilter)
				b.set(i);
		}
		
		return b;
	}
	
	private void readData () throws Exception {
		
		// track the beginning time of the job
		long startTime = System.nanoTime();
		
		
        try {
        	// reset counters
        	this._filteredCount = 0L;
        	
        	// open file and map to memory
            RandomAccessFile aFile = new RandomAccessFile(this._filename, "r");
            FileChannel inChannel = aFile.getChannel();
            
            
            // get file size
            long fileSize = inChannel.size();
            
            if (this._filterHighRange <= 0)
            	this._filterHighRange = fileSize;
            
            int mapSize = (int)(this._filterHighRange - this._filterLowRange + 1);
            
            // Force the max file size to be 2 billion; 2Gb
            if (fileSize > DIM_MAX_RECORDS) {
            	aFile.close();
            	throw new Exception ("File size cannot exceed " + DIM_MAX_RECORDS + " bytes");
            }
            
            // Read all the bytes other than null if there is no filter
            boolean all = true;
            if (_filter != null && _filter.length > 0)
            	all = false;
            
            boolean singleCheck = false;
            // rationalize the filters into ranges from an array to do a faster range
            // based check instead of an array check
            if (_filter.length == 1) { // only one item
            	singleCheck = true;
            }
            
            
            // take the filter inputs and divide them up into ranges for efficiency
            int startPoint = -1;
            int endPoint = -1;
            int k = 0;
            int[][] rangeCheck = new int[255][255]; 
            TreeSet<Integer> t = new TreeSet<Integer>();
            if (_filter.length > 1) {
            	// re-orient the filter to be sorted
            	for (int i = 0; i < _filter.length; i++) {
            		t.add((int)_filter[i]);
            	}
            	
            	// read from the sortedset in ascending order
            	Iterator<Integer> it = t.iterator();
            	int temp = -1, prevtemp = -1;
            	k = 0;
            	while(it.hasNext()) {
            		temp = it.next();
            		if (startPoint == -1) {
            			startPoint = temp;
            			rangeCheck[k][0] = startPoint;
            		}
            		
            		if (endPoint == -1) {
            			endPoint = temp;
            			rangeCheck[k][1] = endPoint;
            		}
            		else {
            			if (temp == (prevtemp + 1)) {
            				endPoint = temp;
            				rangeCheck[k][1] = endPoint;
            			}
            			else {
            				++k;
            				startPoint = temp;
            				endPoint = temp;
            				rangeCheck[k][0] = temp;
            				rangeCheck[k][1] = temp;
            			}
            		}
            		prevtemp = temp;
            	}
            }
            
            // once the ranges are established, determine if they are contiguous
            // or fragmented. If they are fragmented, it is better to loop through individual
            // filter checks instead of range chacks
            int countFragmented = 0;
            for (int i = 0; i <= k; i++) {
            	if (rangeCheck[i][0] == rangeCheck[i][0])
            		++countFragmented;
            }
            
            boolean checkRange = true;
            if ((k+1)/2 < countFragmented)
            	checkRange = false;
            	
            //System.out.println("No of ranges : " + (k+1));
            
            //System.out.println("Map size/File size in bytes : " + mapSize + "/" + fileSize);
            
            // Temporary buffer to pull data from memory 
            MappedByteBuffer buffer = null;

            buffer = inChannel.map(FileChannel.MapMode.READ_ONLY, this._filterLowRange-1, mapSize);
            _computedBitSet = new BitSet((int)(fileSize));
            //_memoryBuffer = new byte[(int)fileSize];
            
	        // read byte by byte till end of line, convert into a long
	        // and add to the structures to be returned to the caller
            // to improve performance of code execution - duplicate the two parts
            // of non range and range based data extraction seperately.
	        if (all) {
	        	this.readDataAll(buffer);
	        }
            
	        // when filter contains only one character to check
	        else if (singleCheck) {
	        	this.readDataSingleCheck(buffer);
	        }
	        
	        // multi range check
	        else if (checkRange) {
	        	this.readDataRange(buffer, k, rangeCheck);
	        }
	        
	        // check ind. filter values
	        else {
	        	this.readDataFilter(buffer);
	        }
            
	        inChannel.close();
            // close the file
            aFile.close();
            
            buffer.clear();
            buffer = null;
            
            if (_memoryBuffer != null)
            	System.out.println("Memory Buffer length : " + _memoryBuffer.length);
            
        } catch (IOException ioe) {
            throw new IOException(ioe);
        } finally {
        	
        	// set the record count
        	if (this._computedBitSet != null)
        		this._filteredCount = this._computedBitSet.cardinality();
        	
        	// track the ending time of the process
            long endTime = System.nanoTime();
            
            // calculate the elapsed time of the process in milli seconds
            this._elapsedTimeInMillis = TimeUnit.MILLISECONDS.convert((endTime - startTime), TimeUnit.NANOSECONDS);
            System.out.println("File based read time : " + this._elapsedTimeInMillis);
        }
        
	}

	@Override
	public void run() {
		
		try {
			// execute the read file method
			this.readData();
		
		}
		catch (Exception ioe) {
			;
		}
		
		// inform observers that the process is complete
		this.notifyObservers(this._filename);
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		long lowRange = 1;
		long highRange = 2000000000;
		
		char[] c = {5};
		char[] c1 = {1};
		char[] c2 = {1};
		char[] c3 = {2};
		char[] c4 = {2};
		char[] c5 = {2};
		
		
		try {
			
			// Get a list of male asian customers born on 5th Jul 2007
			String filename = "c:\\users\\dpras\\tempdata\\day";
			TestDimDataReader hr = new TestDimDataReader(filename, lowRange, highRange);
			System.out.println("Filename: " + hr.getFilename());
			hr.setFilter(c);
			hr.readData();
			
			filename = "c:\\users\\dpras\\tempdata\\month";
			TestDimDataReader hr1 = new TestDimDataReader(filename, lowRange, highRange);
			System.out.println("Filename: " + hr1.getFilename());
			hr1.setFilter(c1);
			hr1.readData();
			
			filename = "c:\\users\\dpras\\tempdata\\year";
			TestDimDataReader hr2 = new TestDimDataReader(filename, lowRange, highRange);
			System.out.println("Filename: " + hr2.getFilename());
			hr2.setFilter(c2);
			hr2.readData();
			
			filename = "c:\\users\\dpras\\tempdata\\sex";
			TestDimDataReader hr3 = new TestDimDataReader(filename, lowRange, highRange);
			System.out.println("Filename: " + hr3.getFilename());
			hr3.setFilter(c3);
			hr3.readData();
			
			filename = "c:\\users\\dpras\\tempdata\\race";
			TestDimDataReader hr4 = new TestDimDataReader(filename, lowRange, highRange);
			System.out.println("Filename: " + hr4.getFilename());
			hr4.setFilter(c4);
			hr4.readData();
			
			filename = "c:\\users\\dpras\\tempdata\\type";
			TestDimDataReader hr5 = new TestDimDataReader(filename, lowRange, highRange);
			System.out.println("Filename: " + hr5.getFilename());
			hr5.setFilter(c5);
			hr5.readData();
			
			long beginTime = System.nanoTime();
			int k = 0;
			
			System.out.println("Begin bit test");
			BitSet result = hr.getResultBitSet();
			BitSet r1 = hr1.getResultBitSet();
			BitSet r2 = hr2.getResultBitSet();
			BitSet r3 = hr3.getResultBitSet();
			BitSet r4 = hr4.getResultBitSet();
			BitSet r5 = hr5.getResultBitSet();
			
			//for (int m = 0; m < 1000; m++) {
				result.and(r1);
				result.and(r2);
				result.and(r3);
				result.and(r4);
				result.and(r5);
			//}
			System.out.println("End bit test");
			
			k = result.cardinality();
			System.out.println("No of records matching intersections :" + k);
			
			//long[] l = result.toLongArray();
			//System.out.println("Length of lomg Array : " + l.length);
			
				
			long endTime = System.nanoTime();
			long diff = TimeUnit.MILLISECONDS.convert((endTime - beginTime), TimeUnit.NANOSECONDS);
			System.out.println("File read time in millis : " + 
					(hr.getElapsedTime() + hr1.getElapsedTime() + hr2.getElapsedTime() + 
					hr3.getElapsedTime() + hr4.getElapsedTime() + hr5.getElapsedTime()));
			//System.out.println("No of records in result BitSet : " + k);
			System.out.println("Operations time in memory in millis : " + diff);
			
			

		
		}
		catch (Exception e ) {
			e.printStackTrace();
		}

	}


}
